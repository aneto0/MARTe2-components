/*
 * Generated with the FPGA Interface C API Generator 20.0
 * for NI-RIO 20.0 or later.
 */
#ifndef __NiFpga_MultiIO_h__
#define __NiFpga_MultiIO_h__

#ifndef NiFpga_Version
   #define NiFpga_Version 200
#endif

#include "NiFpga.h"

/**
 * The filename of the FPGA bitfile.
 *
 * This is a #define to allow for string literal concatenation. For example:
 *
 *    static const char* const Bitfile = "C:\\" NiFpga_MultiIO_Bitfile;
 */
#define NiFpga_MultiIO_Bitfile "NiFpga_MultiIO.lvbitx"

/**
 * The signature of the FPGA bitfile.
 */
static const char* const NiFpga_MultiIO_Signature = "03AB279CA6C34216C3ABAADB90262282";

#if NiFpga_Cpp
extern "C"
{
#endif

typedef enum
{
   NiFpga_MultiIO_IndicatorBool_IndBool = 0x816A
} NiFpga_MultiIO_IndicatorBool;

typedef enum
{
   NiFpga_MultiIO_IndicatorI8_IndI8 = 0x811E
} NiFpga_MultiIO_IndicatorI8;

typedef enum
{
   NiFpga_MultiIO_IndicatorU8_IndU8 = 0x812A
} NiFpga_MultiIO_IndicatorU8;

typedef enum
{
   NiFpga_MultiIO_IndicatorI16_IndI16 = 0x811A
} NiFpga_MultiIO_IndicatorI16;

typedef enum
{
   NiFpga_MultiIO_IndicatorU16_IndU16 = 0x8126
} NiFpga_MultiIO_IndicatorU16;

typedef enum
{
   NiFpga_MultiIO_IndicatorI32_IndI32 = 0x8114
} NiFpga_MultiIO_IndicatorI32;

typedef enum
{
   NiFpga_MultiIO_IndicatorU32_IndU32 = 0x8120,
   NiFpga_MultiIO_IndicatorU32_ticks_counter = 0x8130
} NiFpga_MultiIO_IndicatorU32;

typedef enum
{
   NiFpga_MultiIO_IndicatorI64_IndI64 = 0x8110
} NiFpga_MultiIO_IndicatorI64;

typedef enum
{
   NiFpga_MultiIO_IndicatorU64_IndU64 = 0x812C
} NiFpga_MultiIO_IndicatorU64;

typedef enum
{
   NiFpga_MultiIO_ControlBool_ContBool = 0x816E,
   NiFpga_MultiIO_ControlBool_stop = 0x815A,
   NiFpga_MultiIO_ControlBool_use_counter = 0x8162,
   NiFpga_MultiIO_ControlBool_use_dsfifo_data = 0x8166
} NiFpga_MultiIO_ControlBool;

typedef enum
{
   NiFpga_MultiIO_ControlI8_ContI8 = 0x8146
} NiFpga_MultiIO_ControlI8;

typedef enum
{
   NiFpga_MultiIO_ControlU8_ContU8 = 0x8156
} NiFpga_MultiIO_ControlU8;

typedef enum
{
   NiFpga_MultiIO_ControlI16_ContI16 = 0x8142
} NiFpga_MultiIO_ControlI16;

typedef enum
{
   NiFpga_MultiIO_ControlU16_ContU16 = 0x8152,
   NiFpga_MultiIO_ControlU16_sample_value = 0x8136
} NiFpga_MultiIO_ControlU16;

typedef enum
{
   NiFpga_MultiIO_ControlI32_ContI32 = 0x813C
} NiFpga_MultiIO_ControlI32;

typedef enum
{
   NiFpga_MultiIO_ControlU32_ContU32 = 0x814C,
   NiFpga_MultiIO_ControlU32_cycle_ticks = 0x810C
} NiFpga_MultiIO_ControlU32;

typedef enum
{
   NiFpga_MultiIO_ControlI64_ContI64 = 0x8138
} NiFpga_MultiIO_ControlI64;

typedef enum
{
   NiFpga_MultiIO_ControlU64_ContU64 = 0x8148,
   NiFpga_MultiIO_ControlU64_packet_size = 0x815C
} NiFpga_MultiIO_ControlU64;

typedef enum
{
   NiFpga_MultiIO_TargetToHostFifoU64_FIFO1_U64_R = 0
} NiFpga_MultiIO_TargetToHostFifoU64;

typedef enum
{
   NiFpga_MultiIO_HostToTargetFifoU64_FIFO0_U64_W = 1
} NiFpga_MultiIO_HostToTargetFifoU64;


#if NiFpga_Cpp
}
#endif

#endif
